#!/usr/bin/python
import numpy
import pyquaternion


def convert(data_id):
	calib_filename = '../sequences/' + data_id + '/calib.txt'
	stamps_filename = '../sequences/' + data_id + '/times.txt'
	poses_filename = data_id + '.txt'
	dst_filename = data_id + '_tum.txt'
	dst_filename2 = data_id + '_lidar.txt'

	calib = numpy.loadtxt(calib_filename, dtype=object)
	lidar2cam = numpy.identity(4)
	lidar2cam[:3, :4] = calib[-1][1:].reshape(3, 4)
	cam2lidar = numpy.linalg.inv(lidar2cam)

	stamps = numpy.loadtxt(stamps_filename)
	kitti_poses = numpy.loadtxt(poses_filename)

	def cvt_frame(mat):
		cam_pose = numpy.identity(4)
		cam_pose[:3, :4] = mat.reshape(3, 4)
		lidar_pose = cam2lidar.dot(cam_pose).dot(lidar2cam)

		return lidar_pose[:3, :].flatten()

	kitti_poses = [cvt_frame(x) for x in kitti_poses]

	def cvt2tum(mat):
		mat = mat.reshape(3, 4)
		quat = pyquaternion.Quaternion(matrix=mat[:3, :3], atol=1e-6, rtol=1e-6)
		return list(mat[:3, 3]) + [quat.x, quat.y, quat.z, quat.w]

	tum_poses = [cvt2tum(x) for x in kitti_poses]

	with open(dst_filename, 'w') as f:
		for stamp, pose in zip(stamps, tum_poses):
			print(('%.6f' + ' %.6f' * 7) % ((stamp,) + tuple(pose)))
			print(('%.6f' + ' %.6f' * 7) % ((stamp,) + tuple(pose)), file=f)

	with open(dst_filename2, 'w') as f:
		for pose in kitti_poses:
			line = ('%.9f' + ' %.9f' * 11) % tuple(pose.tolist())
			print(line)
			print(line, file=f)


def main():
	for i in range(11):
		data_id = '%02d' % i
		convert(data_id)

if __name__ == '__main__':
	main()
